
package ClassVo;

public class Pelicula {
    private int id;
    protected String nombre;
    private String genero;
    private String Fecha_lanzamiento;
    private String audio;
    private String Director;
    private int duracion;
    private String resultado;

    public String getResultado() {
        return resultado;
    }

    public void setResultado(String resultado) {
        this.resultado = resultado;
    }
    
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getFecha_lanzamiento() {
        return Fecha_lanzamiento;
    }

    public void setFecha_lanzamiento(String Fecha_lanzamiento) {
        this.Fecha_lanzamiento = Fecha_lanzamiento;
    }

    public String getAudio() {
        return audio;
    }

    public void setAudio(String audio) {
        this.audio = audio;
    }

    public String getDirector() {
        return Director;
    }

    public void setDirector(String Director) {
        this.Director = Director;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    @Override
    public String toString() {
        return "Pelicula{" + "id=" + id + ", nombre=" + nombre + ", genero=" + genero + ", Fecha_lanzamiento=" + Fecha_lanzamiento + ", audio=" + audio + ", Director=" + Director + ", duracion=" + duracion + ", resultado=" + resultado + '}';
    }
    
    
}
