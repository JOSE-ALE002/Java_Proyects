
package ClassDAO;

import ClassVo.Libro;
import ConexionDB.ConexionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class LibroDAO extends ClassAbstract.Publicacion{
    public static String registrarLibro(Libro l1) {
        String result = null, last = null;
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "INSERT INTO Libro values(null,?,?,?,?,?,?,?)";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, l1.getNombre());
            pst.setString(2, l1.getEditorial());
            pst.setString(3, l1.getIdioma());
            pst.setInt(4, l1.getPaginas());
            pst.setString(5, l1.getGenero());
            pst.setString(6, l1.getFecha());
            pst.setInt(7, l1.getCapitulo());
            pst.execute();
            pst = cn.prepareStatement("SELECT MAX(id_libro) AS id FROM Libro");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                last = rs.getString(1);
            }
            result = "Libro registrada con exito, ID:" + last;
        } catch (SQLException e) {
            result = "Error en la consulta: " + e.getMessage();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                result = "Error: " + e;
            }
        }
        return result;
    }

    public static String actualizarLibro(Libro l1) {
        String result = null, last = null;
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "UPDATE Libro SET titulo=?, escritor=?, idioma=?, paginas=?, genero_libro=?, fecha_libro = ?, capitulos=? WHERE id_libro=?";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, l1.getNombre());
            pst.setString(2, l1.getEditorial());
            pst.setString(3, l1.getIdioma());
            pst.setInt(4, l1.getPaginas());
            pst.setString(5, l1.getGenero());
            pst.setString(6, l1.getFecha());
            pst.setInt(7, l1.getCapitulo());
            pst.setInt(8, l1.getId());
            pst.execute();

            result = "Libro actualizada con exito, ID:" + l1.getId();
        } catch (SQLException e) {
            result = "Error en la consulta: " + e.getMessage();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                result = "Error: " + e;
            }
        }
        return result;
    }
    
    public static Libro buscarLibro(String clave) {
        Libro l1 = new Libro();
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "SELECT * FROM Libro WHERE titulo = ?";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, clave);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                l1.setId(Integer.parseInt(rs.getString(1)));
                l1.setNombre(rs.getString(2));
                l1.setEditorial(rs.getString(3));
                l1.setIdioma(rs.getString(4));
                l1.setPaginas(rs.getInt(5));
                l1.setGenero(rs.getString(6));
                l1.setFecha(rs.getString(7));
                l1.setCapitulo(rs.getInt(8));
                l1.setResultado("Busqueda exitosa");
            }else{
                l1.setResultado("No encontrado");
            }
            
        } catch (SQLException e) {
            l1.setResultado("Error en la consulta: " + e.getMessage());
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                l1.setResultado("Error: " + e);
            }
        }
        return l1;
    }

    public static String eliminarLibro(String clave) {
        String result = null;
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "DELETE FROM Libro WHERE titulo = ?";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, clave);
            pst.executeUpdate();
            result = "Libro eliminada con exito";
        } catch (SQLException e) {
            result = "Error en la consulta: " + e.getMessage();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                result = "Error: " + e;
            }
        }
        return result;
    }

    @Override
    public ArrayList<Libro> mostrarDatos() {
        ArrayList<Libro> arrProv = new ArrayList<Libro>();
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        Libro c1 = null;
        String sql = "SELECT * FROM Libro";
        try {
            pst = cn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                c1 = new Libro();
                c1.setId(rs.getInt(1));
                c1.setNombre(rs.getString(2));
                c1.setEditorial(rs.getString(3));
                c1.setIdioma(rs.getString(4));
                c1.setPaginas(rs.getInt(5));
                c1.setGenero(rs.getString(6));
                c1.setFecha(rs.getString(7));
                c1.setCapitulo(rs.getInt(8));
                if (arrProv.isEmpty()) {
                    arrProv.add(0, c1);
                } else {
                    arrProv.add(c1);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en la consulta: " + e.getMessage());
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                System.out.println("Error: " + e);
            }
        }
        return arrProv;   
    }
}
