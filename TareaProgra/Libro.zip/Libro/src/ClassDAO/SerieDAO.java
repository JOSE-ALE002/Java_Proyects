/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassDAO;

import ClassVo.Serie;
import ConexionDB.ConexionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


public class SerieDAO extends ClassAbstract.Film{
    public static String registrarSerie(Serie s1) {
        String result = null, last = null;
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "INSERT INTO Serie values(null,?,?,?,?,?,?,?,?)";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, s1.getNombre());
            pst.setString(2, s1.getGenero());
            pst.setString(3, s1.getFecha_lanzamiento());
            pst.setString(4, s1.getAudio());
            pst.setString(5, s1.getDirector());
            pst.setInt(6, s1.getDuracion());
            pst.setInt(7, s1.getTemporadas());
            pst.setInt(8, s1.getCapitulos());
            pst.execute();
            pst = cn.prepareStatement("SELECT MAX(id_serie) AS id FROM Serie");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                last = rs.getString(1);
            }
            result = "Serie registrada con exito, ID:" + last;
        } catch (SQLException e) {
            result = "Error en la consulta: " + e.getMessage();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                result = "Error: " + e;
            }
        }
        return result;
    }

    public static String actualizarSerie(Serie s1) {
        String result = null, last = null;
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "UPDATE Serie SET nombre_serie=?, genero_serie=?, fecha_serie=?, audio_serie=?, director_serie=?, duracion_serie = ?, temporadas=?, capitulos=?  WHERE id_serie=?";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, s1.getNombre());
            pst.setString(2, s1.getGenero());
            pst.setString(3, s1.getFecha_lanzamiento());
            pst.setString(4, s1.getAudio());
            pst.setString(5, s1.getDirector());
            pst.setInt(6, s1.getDuracion());
            pst.setInt(7, s1.getTemporadas());
            pst.setInt(8, s1.getCapitulos());
            pst.setInt(9, s1.getId());
            pst.execute();

            result = "Serie actualizada con exito, ID:" + s1.getId();
        } catch (SQLException e) {
            result = "Error en la consulta: " + e.getMessage();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                result = "Error: " + e;
            }
        }
        return result;
    }
    
    public static Serie buscarSerie(String clave) {
        Serie s1 = new Serie();
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "SELECT * FROM Serie WHERE nombre_serie = ?";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, clave);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                s1.setId(Integer.parseInt(rs.getString(1)));
                s1.setNombre(rs.getString(2));
                s1.setGenero(rs.getString(3));
                s1.setFecha_lanzamiento(rs.getString(4));
                s1.setAudio(rs.getString(5));
                s1.setDirector(rs.getString(6));
                s1.setDuracion(rs.getInt(7));
                s1.setTemporadas(rs.getInt(8));
                s1.setCapitulos(rs.getInt(9));
                s1.setResultado("Busqueda exitosa");
            }else{
                s1.setResultado("No encontrado");
            }
            
        } catch (SQLException e) {
            s1.setResultado("Error en la consulta: " + e.getMessage());
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                s1.setResultado("Error: " + e);
            }
        }
        return s1;
    }

    public static String eliminarSerie(String clave) {
        String result = null;
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "DELETE FROM Serie WHERE nombre_serie = ?";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, clave);
            pst.executeUpdate();
            result = "Serie eliminada con exito";
        } catch (SQLException e) {
            result = "Error en la consulta: " + e.getMessage();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                result = "Error: " + e;
            }
        }
        return result;
    }

    @Override
    public ArrayList<Serie> cargarDatos() {
    ArrayList<Serie> arrProv = new ArrayList<Serie>();
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        Serie c1 = null;
        String sql = "SELECT * FROM Serie";
        try {
            pst = cn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                c1 = new Serie();
                c1.setId(rs.getInt(1));
                c1.setNombre(rs.getString(2));
                c1.setGenero(rs.getString(3));
                c1.setFecha_lanzamiento(rs.getString(4));
                c1.setAudio(rs.getString(5));
                c1.setDirector(rs.getString(6));
                c1.setDuracion(rs.getInt(7));
                c1.setTemporadas(rs.getInt(8));
                c1.setCapitulos(rs.getInt(9));
                if (arrProv.isEmpty()) {
                    arrProv.add(0, c1);
                } else {
                    arrProv.add(c1);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en la consulta: " + e.getMessage());
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                System.out.println("Error: " + e);
            }
        }
        return arrProv;
    }    
}
    
/**/
