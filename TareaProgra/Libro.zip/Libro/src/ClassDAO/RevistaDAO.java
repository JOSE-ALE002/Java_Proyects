/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassDAO;

import ClassVo.Revista;
import ConexionDB.ConexionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class RevistaDAO extends ClassAbstract.Publicacion{
    public static String registrarRevista(Revista r1) {
        String result = null, last = null;
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "INSERT INTO Revista values(null,?,?,?,?,?,?)";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, r1.getNombre());
            pst.setString(2, r1.getEditorial());
            pst.setString(3, r1.getIdioma());
            pst.setInt(4, r1.getPaginas());
            pst.setString(5, r1.getGenero());
            pst.setString(6, r1.getFecha());
            pst.execute();
            pst = cn.prepareStatement("SELECT MAX(id_revista) AS id FROM Revista");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                last = rs.getString(1);
            }
            result = "Revista registrada con exito, ID:" + last;
        } catch (SQLException e) {
            result = "Error en la consulta: " + e.getMessage();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                result = "Error: " + e;
            }
        }
        return result;
    }

    public static String actualizarRevista(Revista r1) {
        String result = null, last = null;
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "UPDATE Revista SET nombre=?, editorial=?, idioma=?, paginas=?, genero=?, fecha_revista = ? WHERE id_revista=?";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, r1.getNombre());
            pst.setString(2, r1.getEditorial());
            pst.setString(3, r1.getIdioma());
            pst.setInt(4, r1.getPaginas());
            pst.setString(5, r1.getGenero());
            pst.setString(6, r1.getFecha());
            pst.setInt(7, r1.getId());
            pst.execute();

            result = "Revista actualizada con exito, ID:" + r1.getId();
        } catch (SQLException e) {
            result = "Error en la consulta: " + e.getMessage();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                result = "Error: " + e;
            }
        }
        return result;
    }
    
    public static Revista buscarRevista(String clave) {
        Revista r1 = new Revista();
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "SELECT * FROM Revista WHERE nombre = ?";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, clave);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                r1.setId(Integer.parseInt(rs.getString(1)));
                r1.setNombre(rs.getString(2));
                r1.setEditorial(rs.getString(3));
                r1.setIdioma(rs.getString(4));
                r1.setPaginas(rs.getInt(5));
                r1.setGenero(rs.getString(6));
                r1.setFecha(rs.getString(7));
                r1.setResultado("Busqueda exitosa");
            }else{
                r1.setResultado("No encontrado");
            }
            
        } catch (SQLException e) {
            r1.setResultado("Error en la consulta: " + e.getMessage());
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                r1.setResultado("Error: " + e);
            }
        }
        return r1;
    }

    public static String eliminarRevista(String clave) {
        String result = null;
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "DELETE FROM Revista WHERE nombre = ?";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, clave);
            pst.executeUpdate();
            result = "Revista eliminada con exito";
        } catch (SQLException e) {
            result = "Error en la consulta: " + e.getMessage();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                result = "Error: " + e;
            }
        }
        return result;
    }

    @Override
    public ArrayList<Revista> mostrarDatos() {
        ArrayList<Revista> arrProv = new ArrayList<Revista>();
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        Revista c1 = null;
        String sql = "SELECT * FROM Revista";
        try {
            pst = cn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                c1 = new Revista();
                c1.setId(rs.getInt(1));
                c1.setNombre(rs.getString(2));
                c1.setEditorial(rs.getString(3));
                c1.setIdioma(rs.getString(4));
                c1.setPaginas(rs.getInt(5));
                c1.setGenero(rs.getString(6));
                c1.setFecha(rs.getString(7));
                if (arrProv.isEmpty()) {
                    arrProv.add(0, c1);
                } else {
                    arrProv.add(c1);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en la consulta: " + e.getMessage());
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                System.out.println("Error: " + e);
            }
        }
        return arrProv;
    }
}
