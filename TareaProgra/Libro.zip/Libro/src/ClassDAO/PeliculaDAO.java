/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ClassDAO;

import ClassVo.Pelicula;
import ConexionDB.ConexionDB;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;


/**
 *
 * @author joseibanez
 */
public class PeliculaDAO extends ClassAbstract.Film{
    public static String registrarPelicula(Pelicula p1) {
        String result = null, last = null;
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "INSERT INTO Pelicula values(null,?,?,?,?,?,?)";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, p1.getNombre());
            pst.setString(2, p1.getGenero());
            pst.setString(3, p1.getFecha_lanzamiento());
            pst.setString(4, p1.getAudio());
            pst.setString(5, p1.getDirector());
            pst.setInt(6, p1.getDuracion());
            pst.execute();
            pst = cn.prepareStatement("SELECT MAX(id_pelicula) AS id FROM Pelicula");
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                last = rs.getString(1);
            }
            result = "Pelicula registrada con exito, ID:" + last;
        } catch (SQLException e) {
            result = "Error en la consulta: " + e.getMessage();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                result = "Error: " + e;
            }
        }
        return result;
    }

    public static String actualizarPelicula(Pelicula p1) {
        String result = null, last = null;
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "UPDATE Pelicula SET nombre=?, genero=?, fecha_lanzamiento=?, audio=?, director=?, duracion = ? WHERE id_pelicula=?";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, p1.getNombre());
            pst.setString(2, p1.getGenero());
            pst.setString(3, p1.getFecha_lanzamiento());
            pst.setString(4, p1.getAudio());
            pst.setString(5, p1.getDirector());
            pst.setInt(6, p1.getDuracion());
            pst.setInt(7, p1.getId());
            pst.execute();

            result = "Pelicula actualizada con exito, ID:" + p1.getId();
        } catch (SQLException e) {
            result = "Error en la consulta: " + e.getMessage();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                result = "Error: " + e;
            }
        }
        return result;
    }
    
    public static Pelicula buscarPelicula(String clave) {
        Pelicula p1 = new Pelicula();
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "SELECT * FROM Pelicula WHERE nombre = ?";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, clave);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                p1.setId(Integer.parseInt(rs.getString(1)));
                p1.setNombre(rs.getString(2));
                p1.setGenero(rs.getString(3));
                p1.setFecha_lanzamiento(rs.getString(4));
                p1.setAudio(rs.getString(5));
                p1.setDirector(rs.getString(6));
                p1.setDuracion(rs.getInt(7));
                p1.setResultado("Busqueda exitosa");
            }else{
                p1.setResultado("No encontrado");
            }
            
        } catch (SQLException e) {
            p1.setResultado("Error en la consulta: " + e.getMessage());
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                p1.setResultado("Error: " + e);
            }
        }
        return p1;
    }

    public static String eliminarPelicula(String clave) {
        String result = null;
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        String sql = "DELETE FROM Pelicula WHERE nombre = ?";
        try {
            pst = cn.prepareStatement(sql);
            pst.setString(1, clave);
            pst.executeUpdate();
            result = "Pelicula eliminada con exito";
        } catch (SQLException e) {
            result = "Error en la consulta: " + e.getMessage();
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                result = "Error: " + e;
            }
        }
        return result;
    }

    @Override
    public ArrayList<Pelicula> cargarDatos() {
        ArrayList<Pelicula> lista = new ArrayList<Pelicula>();
        ConexionDB cc = new ConexionDB();
        Connection cn = cc.getConnection();
        PreparedStatement pst = null;
        Pelicula c1 = null;
        String sql = "SELECT * FROM Pelicula";
        try {
            pst = cn.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();
            while (rs.next()) {
                c1 = new Pelicula();
                c1.setId(rs.getInt(1));
                c1.setNombre(rs.getString(2));
                c1.setGenero(rs.getString(3));
                c1.setFecha_lanzamiento(rs.getString(4));
                c1.setAudio(rs.getString(5));
                c1.setDirector(rs.getString(6));
                c1.setDuracion(rs.getInt(7));
                if (lista.isEmpty()) {
                    lista.add(0, c1);
                } else {
                    lista.add(c1);
                }
            }
        } catch (SQLException e) {
            System.out.println("Error en la consulta: " + e.getMessage());
        } finally {
            try {
                if (cn != null) {
                    cn.close();
                    pst.close();
                }
            } catch (Exception e) {
                System.out.println("Error: " + e);
            }
        }
        
        return lista;
    }
}
